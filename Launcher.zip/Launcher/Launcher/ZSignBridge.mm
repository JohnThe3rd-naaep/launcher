#import "ZSignBridge.h"

// zsign's main() is renamed to zsign_main at compile time (-Dmain=zsign_main in project.yml).
extern int zsign_main(int argc, char *argv[]);

@implementation ZSignBridge
+ (int)signIPA:(NSString *)ipa p12:(NSString *)p12 password:(NSString *)password profile:(NSString *)profile output:(NSString *)output {
    const char *args[] = {"zsign", "-k", p12.UTF8String, "-p", password.UTF8String,
                          "-m", profile.UTF8String, "-o", output.UTF8String, "-z", "1", ipa.UTF8String, NULL};
    return zsign_main(12, (char **)args);
}
@end
