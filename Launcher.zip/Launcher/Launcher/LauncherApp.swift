import SwiftUI

@main
struct LauncherApp: App {
    @StateObject private var lib = Library()
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            LibraryView()
                .environmentObject(lib)
                .preferredColorScheme(.dark)
                .onChange(of: phase) { _, p in if p == .active { lib.resume() } }
        }
    }
}
