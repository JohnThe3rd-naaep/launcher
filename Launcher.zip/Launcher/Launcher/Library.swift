import SwiftUI

enum Kind: String, Codable { case switchROM, ipa }

struct Game: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var kind: Kind
    var bookmark: Data
    var titleID = ""
    var seconds = 0.0
    var lastPlayed: Date?
    var cover: Data?

    var playtime: String {
        let m = Int(seconds / 60)
        if m < 1 { return "Not played yet" }
        return m < 60 ? "\(m) min" : "\(m / 60) h \(m % 60) min"
    }
}

@MainActor
final class Library: ObservableObject {
    static let defaultTemplate = "melonx://game?id={id}"   // unverified: edit in Settings

    @Published var games: [Game] = [] { didSet { persist() } }
    @Published var message: String?
    @Published var signedFile: URL?
    @Published var busy = false
    private var session: (id: UUID, start: Date)?
    private let file = URL.documentsDirectory.appending(path: "library.json")

    init() {
        if let d = try? Data(contentsOf: file), let g = try? JSONDecoder().decode([Game].self, from: d) { games = g }
    }

    private func persist() { try? JSONEncoder().encode(games).write(to: file) }

    func add(_ urls: [URL]) {
        for u in urls {
            let ok = u.startAccessingSecurityScopedResource()
            defer { if ok { u.stopAccessingSecurityScopedResource() } }
            guard let b = try? u.bookmarkData() else { continue }
            let kind: Kind = u.pathExtension.lowercased() == "ipa" ? .ipa : .switchROM
            let raw = u.deletingPathExtension().lastPathComponent
            var g = Game(name: Covers.cleanName(raw), kind: kind, bookmark: b)
            if kind == .ipa { g.cover = Covers.ipaIcon(at: u) } else { g.titleID = Covers.titleID(in: raw) ?? "" }
            games.append(g)
            if kind == .switchROM { Task { await fetchCover(g.id) } }
        }
    }

    func fetchCover(_ id: UUID) async {
        guard let g = games.first(where: { $0.id == id }), let d = await Covers.igdb(g.name),
              let i = games.firstIndex(where: { $0.id == id }) else { return }
        games[i].cover = d
    }

    func play(_ g: Game) {
        switch g.kind {
        case .switchROM:
            let t = UserDefaults.standard.string(forKey: "launchTemplate") ?? Self.defaultTemplate
            let name = g.name.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
            let s = t.replacingOccurrences(of: "{id}", with: g.titleID).replacingOccurrences(of: "{name}", with: name)
            guard let url = URL(string: s) else { message = "The MeloNX launch link is invalid. Check Settings."; return }
            session = (g.id, Date())
            UIApplication.shared.open(url) { ok in
                Task { @MainActor in
                    if !ok { self.session = nil; self.message = "Couldn't open MeloNX. Check that it's installed and the launch link in Settings is right." }
                }
            }
        case .ipa:
            busy = true
            Task {
                do { signedFile = try await Signer.sign(g) }
                catch { message = error.localizedDescription }
                busy = false
            }
        }
    }

    /// Called when this app becomes active again; adds the time spent away to the game.
    func resume() {
        guard let s = session else { return }
        session = nil
        if let i = games.firstIndex(where: { $0.id == s.id }) {
            games[i].seconds += Date().timeIntervalSince(s.start)
            games[i].lastPlayed = Date()
        }
    }
}
