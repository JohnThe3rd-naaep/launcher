import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage("launchTemplate") private var template = Library.defaultTemplate
    @State private var password = Keychain.get("p12password") ?? ""
    @State private var picking: URL?
    @State private var importing = false
    @State private var refresh = false
    @State private var igdbID = Keychain.get("igdbID") ?? ""
    @State private var igdbSecret = Keychain.get("igdbSecret") ?? ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Launch link", text: $template).textInputAutocapitalization(.never).autocorrectionDisabled()
                } header: { Text("MeloNX") } footer: {
                    Text("Opened when you press Play. {id} becomes the game's Title ID and {name} its name. Check MeloNX's docs for the link format it accepts.")
                }
                Section {
                    TextField("IGDB client ID", text: $igdbID).textInputAutocapitalization(.never).autocorrectionDisabled()
                        .onChange(of: igdbID) { _, v in Keychain.set(v, for: "igdbID") }
                    SecureField("IGDB client secret", text: $igdbSecret)
                        .onChange(of: igdbSecret) { _, v in Keychain.set(v, for: "igdbSecret") }
                } header: { Text("Cover art") } footer: {
                    Text("Switch covers come from IGDB. Get free keys at api-docs.igdb.com (needs a Twitch account). IPA icons are read from the file itself.")
                }
                Section {
                    row("Certificate (.p12)", FileManager.default.fileExists(atPath: Signer.certURL.path), Signer.certURL)
                    row("Provisioning profile", FileManager.default.fileExists(atPath: Signer.profileURL.path), Signer.profileURL)
                    SecureField("Certificate password", text: $password)
                        .onChange(of: password) { _, v in Keychain.set(v, for: "p12password") }
                } header: { Text("Signing") } footer: {
                    Text("Your certificate stays on this device. The password is kept in the Keychain.")
                }
            }
            .id(refresh)
            .navigationTitle("Settings").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.data]) { r in
                if case .success(let u) = r, let dest = picking { try? Signer.store(u, as: dest); refresh.toggle() }
            }
        }
    }

    private func row(_ title: String, _ done: Bool, _ dest: URL) -> some View {
        Button { picking = dest; importing = true } label: {
            HStack {
                Text(title).foregroundStyle(.primary)
                Spacer()
                Text(done ? "Imported" : "Choose file").foregroundStyle(.secondary)
            }
        }
    }
}
