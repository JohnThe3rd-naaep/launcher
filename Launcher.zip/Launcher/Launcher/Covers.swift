import UIKit
import ZIPFoundation

enum Covers {
    /// Reads the app icon straight out of the IPA (no network).
    static func ipaIcon(at url: URL) -> Data? {
        guard let ar = try? Archive(url: url, accessMode: .read) else { return nil }
        let icons = ar.filter {
            let p = $0.path.split(separator: "/")
            return p.count == 3 && p[0] == "Payload" && p[2].lowercased().contains("appicon") && p[2].lowercased().hasSuffix(".png")
        }
        guard let best = icons.max(by: { $0.uncompressedSize < $1.uncompressedSize }) else { return nil }
        var data = Data()
        _ = try? ar.extract(best) { data.append($0) }
        return UIImage(data: data)?.pngData()   // decodes Apple's optimised PNG into a normal one
    }

    /// "Game_Name [0100ABC...] (v1.0.0)" -> "Game Name"
    static func cleanName(_ s: String) -> String {
        let t = s.replacingOccurrences(of: "[_.]", with: " ", options: .regularExpression)
            .replacingOccurrences(of: "[\\[(][^\\])]*[\\])]", with: "", options: .regularExpression)
        let r = t.split(separator: " ").joined(separator: " ")
        return r.isEmpty ? s : r
    }

    static func titleID(in s: String) -> String? {
        guard let r = s.range(of: "[0-9A-Fa-f]{16}", options: .regularExpression) else { return nil }
        return String(s[r]).uppercased()
    }

    /// Box art from IGDB using your own free keys (Settings).
    static func igdb(_ name: String) async -> Data? {
        guard let id = Keychain.get("igdbID"), let secret = Keychain.get("igdbSecret"), !id.isEmpty, !secret.isEmpty else { return nil }
        do {
            var tr = URLRequest(url: URL(string: "https://id.twitch.tv/oauth2/token?client_id=\(id)&client_secret=\(secret)&grant_type=client_credentials")!)
            tr.httpMethod = "POST"
            let (td, _) = try await URLSession.shared.data(for: tr)
            guard let token = (try JSONSerialization.jsonObject(with: td) as? [String: Any])?["access_token"] as? String else { return nil }
            var r = URLRequest(url: URL(string: "https://api.igdb.com/v4/games")!)
            r.httpMethod = "POST"
            r.setValue(id, forHTTPHeaderField: "Client-ID")
            r.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            let q = name.replacingOccurrences(of: "\"", with: "")
            r.httpBody = Data("search \"\(q)\"; fields cover.image_id; where platforms = (130) & cover != null; limit 1;".utf8)
            let (d, _) = try await URLSession.shared.data(for: r)
            guard let arr = try JSONSerialization.jsonObject(with: d) as? [[String: Any]],
                  let img = (arr.first?["cover"] as? [String: Any])?["image_id"] as? String,
                  let u = URL(string: "https://images.igdb.com/igdb/image/upload/t_cover_big/\(img).jpg") else { return nil }
            return try await URLSession.shared.data(from: u).0
        } catch { return nil }
    }
}
