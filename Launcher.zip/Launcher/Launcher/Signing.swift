import Foundation
import Security

enum Keychain {
    static func set(_ value: String, for key: String) {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrAccount as String: key]
        SecItemDelete(q as CFDictionary)
        var a = q; a[kSecValueData as String] = Data(value.utf8)
        SecItemAdd(a as CFDictionary, nil)
    }
    static func get(_ key: String) -> String? {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrAccount as String: key,
                                kSecReturnData as String: true]
        var out: AnyObject?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess, let d = out as? Data else { return nil }
        return String(data: d, encoding: .utf8)
    }
}

enum Signer {
    static let dir = URL.applicationSupportDirectory.appending(path: "Signing")
    static var certURL: URL { dir.appending(path: "cert.p12") }
    static var profileURL: URL { dir.appending(path: "profile.mobileprovision") }
    static var ready: Bool {
        FileManager.default.fileExists(atPath: certURL.path) && FileManager.default.fileExists(atPath: profileURL.path)
    }

    /// Copies a picked certificate or profile into the app's private folder.
    static func store(_ url: URL, as dest: URL) throws {
        let ok = url.startAccessingSecurityScopedResource()
        defer { if ok { url.stopAccessingSecurityScopedResource() } }
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        try? FileManager.default.removeItem(at: dest)
        try FileManager.default.copyItem(at: url, to: dest)
    }

    struct NotReady: LocalizedError {
        var errorDescription: String? { "Add your certificate, password and provisioning profile in Settings first." }
    }
    struct Failed: LocalizedError {
        var errorDescription: String? { "Signing failed. Check the certificate password and that the profile matches the certificate." }
    }

    static let outDir = URL.documentsDirectory.appending(path: "Signed")

    /// Signs the IPA with zsign (see ZSignBridge.mm) and returns the signed file.
    static func sign(_ game: Game) async throws -> URL {
        guard ready else { throw NotReady() }
        var stale = false
        let src = try URL(resolvingBookmarkData: game.bookmark, bookmarkDataIsStale: &stale)
        let fm = FileManager.default
        let work = fm.temporaryDirectory.appending(path: UUID().uuidString)
        try fm.createDirectory(at: work, withIntermediateDirectories: true)
        let input = work.appending(path: "in.ipa")
        let ok = src.startAccessingSecurityScopedResource()
        defer { if ok { src.stopAccessingSecurityScopedResource() } }
        try fm.copyItem(at: src, to: input)
        try fm.createDirectory(at: outDir, withIntermediateDirectories: true)
        let out = outDir.appending(path: "\(game.name).ipa")
        try? fm.removeItem(at: out)
        let pw = Keychain.get("p12password") ?? ""
        let (cert, prof) = (certURL.path, profileURL.path)
        let code = await Task.detached { () -> Int32 in
            FileManager.default.changeCurrentDirectoryPath(work.path)
            return ZSignBridge.signIPA(input.path, p12: cert, password: pw, profile: prof, output: out.path)
        }.value
        try? fm.removeItem(at: work)
        guard code == 0, fm.fileExists(atPath: out.path) else { throw Failed() }
        return out
    }
}
