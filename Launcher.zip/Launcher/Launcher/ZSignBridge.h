#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
@interface ZSignBridge : NSObject
/// Runs zsign: zsign -k p12 -p password -m profile -o output ipa. Returns 0 on success.
+ (int)signIPA:(NSString *)ipa p12:(NSString *)p12 password:(NSString *)password profile:(NSString *)profile output:(NSString *)output;
@end
NS_ASSUME_NONNULL_END
