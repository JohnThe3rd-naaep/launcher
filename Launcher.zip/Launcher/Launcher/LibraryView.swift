import SwiftUI
import PhotosUI

// Uses the system font, which is SF Pro on iPhone.

func tint(_ name: String, _ shift: Double = 0) -> Color {
    var h: UInt32 = 5381
    for c in name.unicodeScalars { h = h &* 33 &+ c.value }
    return Color(hue: (Double(h % 360) + shift).truncatingRemainder(dividingBy: 360) / 360, saturation: 0.55, brightness: 0.5)
}

struct Cover: View {
    let game: Game
    var radius: CGFloat = 20
    var body: some View {
        ZStack {
            if let d = game.cover, let ui = UIImage(data: d) {
                Image(uiImage: ui).resizable().scaledToFill()
            } else {
                LinearGradient(colors: [tint(game.name), tint(game.name, 40)], startPoint: .topLeading, endPoint: .bottomTrailing)
                Text(String(game.name.prefix(1)).uppercased())
                    .font(.system(size: 64, weight: .semibold)).foregroundStyle(.white.opacity(0.9))
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: radius, style: .continuous))
    }
}

struct LibraryView: View {
    @EnvironmentObject var lib: Library
    @State private var sel: UUID?
    @State private var importing = false
    @State private var showSettings = false
    @State private var editing: Game?

    private var current: Game? { lib.games.first { $0.id == (sel ?? lib.games.first?.id) } }

    var body: some View {
        ZStack {
            backdrop
            VStack(alignment: .leading, spacing: 0) {
                topBar
                Spacer(minLength: 0)
                info
                shelf
            }
            .padding(.horizontal, 44)
            .padding(.vertical, 12)
        }
        .persistentSystemOverlays(.hidden)
        .fileImporter(isPresented: $importing, allowedContentTypes: [.data], allowsMultipleSelection: true) { r in
            if case .success(let urls) = r { lib.add(urls) }
        }
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(item: $editing) { EditSheet(game: $0) }
        .sheet(item: Binding(get: { lib.signedFile.map(ShareItem.init) }, set: { if $0 == nil { lib.signedFile = nil } })) {
            ActivityView(url: $0.url).presentationDetents([.medium, .large])
        }
        .overlay {
            if lib.busy { ProgressView("Signing…").padding(28).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous)) }
        }
        .alert("Launcher", isPresented: Binding(get: { lib.message != nil }, set: { if !$0 { lib.message = nil } })) {
            Button("OK", role: .cancel) {}
        } message: { Text(lib.message ?? "") }
    }

    private var topBar: some View {
        HStack {
            Text("Games").font(.system(size: 22, weight: .bold))
                .overlay(alignment: .bottom) { Rectangle().frame(height: 3).offset(y: 6) }
            Spacer()
            HStack(spacing: 22) {
                Button { importing = true } label: { Image(systemName: "plus") }
                Button { showSettings = true } label: { Image(systemName: "gearshape") }
                Text(Date.now, format: .dateTime.hour().minute()).font(.system(size: 17))
            }
            .font(.system(size: 20))
        }
        .foregroundStyle(.white)
    }

    /// Full-screen art of the selected game, like the PS5 home screen.
    private var backdrop: some View {
        ZStack {
            Color.black
            if let g = current {
                if let d = g.cover, let ui = UIImage(data: d) {
                    Image(uiImage: ui).resizable().scaledToFill().blur(radius: 18).scaleEffect(1.15)
                } else {
                    tint(g.name)
                }
            }
            Color.black.opacity(0.35)
            LinearGradient(colors: [.clear, .black.opacity(0.7)], startPoint: .center, endPoint: .bottom)
        }
        .ignoresSafeArea()
        .animation(.easeInOut(duration: 0.4), value: current?.id)
    }

    @ViewBuilder private var info: some View {
        if let g = current {
            VStack(alignment: .leading, spacing: 8) {
                Text(g.kind == .switchROM ? "Switch · \(g.playtime)" : "iOS app · \(g.playtime)")
                    .font(.system(size: 14)).foregroundStyle(.white.opacity(0.8))
                Text(g.name).font(.system(size: 32, weight: .bold)).lineLimit(1).foregroundStyle(.white)
                HStack(spacing: 12) {
                    Button { lib.play(g) } label: {
                        Label(g.kind == .switchROM ? "Play" : "Sign & install", systemImage: "play.fill")
                            .font(.system(size: 16, weight: .semibold)).padding(.horizontal, 24).padding(.vertical, 10)
                            .background(.white, in: Capsule()).foregroundStyle(.black)
                    }
                    Button { editing = g } label: {
                        Image(systemName: "ellipsis").font(.system(size: 16, weight: .semibold)).foregroundStyle(.white)
                            .frame(width: 40, height: 40).background(.white.opacity(0.2), in: Circle())
                    }
                }
            }
            .padding(.bottom, 18)
        } else {
            VStack(alignment: .leading, spacing: 6) {
                Text("No games yet").font(.system(size: 30, weight: .bold))
                Text("Tap + to import Switch ROMs or IPA files.").foregroundStyle(.white.opacity(0.75))
            }
            .foregroundStyle(.white).padding(.bottom, 24)
        }
    }

    private var shelf: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            LazyHStack(alignment: .top, spacing: 16) {
                ForEach(lib.games) { g in
                    let on = g.id == current?.id
                    VStack(alignment: .leading, spacing: 8) {
                        Cover(game: g, radius: on ? 20 : 16)
                            .frame(width: on ? 104 : 84, height: on ? 104 : 84)
                            .overlay { RoundedRectangle(cornerRadius: on ? 20 : 16, style: .continuous).stroke(.white, lineWidth: on ? 3 : 0) }
                        Text(g.playtime).font(.system(size: 12)).foregroundStyle(.white.opacity(on ? 0.95 : 0.6))
                    }
                    .id(g.id)
                    .onTapGesture { if on { lib.play(g) } else { withAnimation(.snappy) { sel = g.id } } }
                    .animation(.snappy, value: on)
                }
            }
            .scrollTargetLayout()
            .padding(.vertical, 4)
        }
        .scrollPosition(id: $sel, anchor: .leading)
        .scrollTargetBehavior(.viewAligned)
        .frame(height: 140)
    }
}

struct EditSheet: View {
    @EnvironmentObject var lib: Library
    @Environment(\.dismiss) private var dismiss
    @State var game: Game
    @State private var photo: PhotosPickerItem?

    init(game: Game) { _game = State(initialValue: game) }

    var body: some View {
        NavigationStack {
            Form {
                TextField("Name", text: $game.name)
                if game.kind == .switchROM { TextField("Title ID (used to launch)", text: $game.titleID).textInputAutocapitalization(.never) }
                PhotosPicker(selection: $photo, matching: .images) { Text("Choose cover art") }
                if game.kind == .switchROM {
                    Button("Find cover art online") { Task { if let d = await Covers.igdb(game.name) { game.cover = d } } }
                }
                Button("Remove from library", role: .destructive) {
                    lib.games.removeAll { $0.id == game.id }; dismiss()
                }
            }
            .navigationTitle("Details").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Save") {
                if let i = lib.games.firstIndex(where: { $0.id == game.id }) { lib.games[i] = game }
                dismiss()
            } } }
            .onChange(of: photo) { _, item in
                Task { if let d = try? await item?.loadTransferable(type: Data.self) { game.cover = d } }
            }
        }
        .presentationDetents([.medium])
    }
}

struct ShareItem: Identifiable { let url: URL; var id: URL { url } }

struct ActivityView: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: [url], applicationActivities: nil) }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}
