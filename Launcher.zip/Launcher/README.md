# Launcher (iOS)
SwiftUI game library: import IPA/Switch ROM files, track play time, launch MeloNX, sign IPAs with your own certificate.

## Build without a Mac
1. Push this folder to a GitHub repo.
2. Actions > Build IPA > Run workflow (it downloads zsign and OpenSSL for you). Download the Launcher-ipa artifact (unsigned).
3. Sign and install it with your usual tool and your own certificate.

## Build with a Mac
`sh scripts/setup_zsign.sh && brew install xcodegen && xcodegen && open Launcher.xcodeproj`

## Cover art
- IPA: icon is read from the file.
- Switch: add free IGDB keys in Settings. A [TitleID] in the filename fills in the Title ID.

## Signing
Settings: add .p12, password, .mobileprovision. Press "Sign & install" on an IPA, then send the signed file to your installer from the share sheet.
If signing fails reading the .p12, re-export it with modern encryption:
`openssl pkcs12 -legacy -in old.p12 -nodes | openssl pkcs12 -export -out new.p12`

## Still to confirm
- MeloNX launch link format (Settings).
- If the build can't find <openssl/...> headers, point HEADER_SEARCH_PATHS at the OpenSSL package's Headers folder.
