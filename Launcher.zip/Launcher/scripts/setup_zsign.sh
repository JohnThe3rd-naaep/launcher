#!/bin/sh
# Downloads zsign's sources into ThirdParty/zsign (run once before xcodegen).
set -e
rm -rf ThirdParty/zsign .zsign-clone
git clone --depth 1 https://github.com/zhlynn/zsign.git .zsign-clone
mkdir -p ThirdParty/zsign
if [ -d .zsign-clone/src ]; then cp -R .zsign-clone/src/. ThirdParty/zsign/
else cp -R .zsign-clone/*.cpp .zsign-clone/*.h .zsign-clone/common ThirdParty/zsign/; fi
rm -rf .zsign-clone
